//
//  ClassViewController.swift
//  homeworkapp
//
//  Created by Michael Behrens on 4/23/19.
//  Copyright © 2019 Michael Behrens. All rights reserved.
//

import UIKit

class ClassViewController: UIViewController {
    
    var viewTitle: String!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        view.backgroundColor = .white
        
        // Do any additional setup after loading the view.
    }
    
}
